<?php
session_start();
if (!isset($_SESSION['is_volunteer_logged_in'])) {
    header('location: login.php');
}
include '../functions.php';

if(isset($_GET['survey_id']))
{
    $survey_id = $_GET['survey_id'];   
    
    $survey = getPreparedSurvey($survey_id);
    
    $_SESSION['current_survey']=$survey;
    header("location: survey-form.php");
    
    
    
    
}

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Welcome Volunteer</title>
        <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>


    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div style="text-align: right; font-size:25px; ">
                        <?php
                        displayVolunteerUserName();
                        ?>
                        | <a href="log-out.php">Log out</a>
                    </div>   
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h3>Take A survey</h3>
                    <?php
                        $user_login = $_SESSION['user_login'];
                        $volunteer_id = getVolunteerID($user_login);
                        
                        $nonTakeSurveyIDs = getNonTakentSurveys($volunteer_id);
                        
                        foreach ($nonTakeSurveyIDs as $survey_id)
                        {
                            $result = getSurvey($survey_id);
                            while($survey = mysqli_fetch_array($result))
                            {
                                ?>
                    <a href="?survey_id=<?php echo $survey_id; ?>"> <?php echo $survey['title']; ?></a><br>
                    <?php
                            }
                            
                            
                        }
                        
                    ?>
                </div> 
            </div>
        </div>


    </body>
</html>
