<?php
session_start();
if (!isset($_SESSION['is_volunteer_logged_in'])) {
    header('location: login.php');
}
include '../functions.php';

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Welcome Volunteer</title>
        <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>


    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div style="text-align: right; font-size:25px; "> <a href="index.php">Home</a>
                        <?php
                        displayVolunteerUserName();
                        ?>
                        | <a href="log-out.php">Log out</a>
                    </div>   
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h3>Survey Submitted Successfully</h3>

                </div> 
            </div>
        </div>


    </body>
</html>
