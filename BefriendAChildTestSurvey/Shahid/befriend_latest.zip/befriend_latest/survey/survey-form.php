<?php
include '../functions.php';
session_start();

$survey = new Survey();
if (!isset($_SESSION['is_volunteer_logged_in'])) {
    header('location: login.php');
}
if (!isset($_SESSION['current_survey'])) {
    header("location: index.php");
} else {

    $survey = $_SESSION['current_survey'];
}

if (isset($_POST['Submit'])) {
    $survey = $_SESSION['current_survey'];
    
    $totalQuestions = $_POST['numberOFQuestiions'];
    $survey_id = $survey->survey_id;
    
    $user_login = $_SESSION['user_login'];
    $user_id = getVolunteerID($user_login);
    saveSurveyTaken($user_id, $survey_id);  
    
    
    
    for ($i = 1; $i <= $totalQuestions; $i++) {
        $answer = $_POST['q' . $i];
        $question_id = $_POST['qid' . $i];

        saveQuestionAnswer($question_id, $user_id, $answer,$survey_id);
    }

    header("location: success.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Welcome Volunteer</title>
        <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>


    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div style="text-align: right; font-size:25px; ">
<?php
displayVolunteerUserName();
?>
                        | <a href="log-out.php">Log out</a>
                    </div>   
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h3><?php echo $survey->title; ?></h3>
                    <form method="post" action="">
                        <input type ="hidden" name="numberOFQuestiions" value="<?php echo count($survey->questions); ?>" >
<?php
$question = new Question();
$counter = 1;
foreach ($survey->questions as $question) {
    ?>
                            <div class="row">

                                <div class="col-md-12">
                                    <label>
                            <?php
                            echo $question->statement;
                            ?>

                                    </label>
                                    <input type="hidden" name="qid<?php echo $counter; ?>" value="<?php echo $question->id; ?>">
                                </div>

                            </div> 
                            <div class="row">
                                <div class="col-md-12">
    <?php
    if ($question->type != "radio") {
        ?>

                                        <input required="" type="text" name="q<?php echo $counter;
        $counter++; ?>"  class="form-control">

                                        <hr>
        <?php
    } else {
        $question_id = $question->id;
        $result = getQuestionOptions($question_id);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                ?>

                                        <input required="" value="<?php echo $row['choice_statement']; ?>"  name="q<?php echo $counter; ?>" type="radio"   > <?php echo $row['choice_statement']; ?><br>
                                                <?php
                                            }
                                            $counter++;
                                            ?>
                                            <hr>
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </div>

                                    <?php
                                }
                                ?>
                        <div class="row">
                            <div class="col-md-3" style="margin-left: auto; margin-right: auto;">
                                <input class="form-control" name="Submit" type="submit" value="Submit">
                            </div>
                        </div>
                    </form>
                </div> 
            </div>
        </div>


    </body>
</html>
