# be_friend_a_child
