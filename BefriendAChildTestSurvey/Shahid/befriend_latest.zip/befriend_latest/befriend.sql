-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2016 at 10:12 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `befriend`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `email_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email_id`, `password`) VALUES
('test@test.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE IF NOT EXISTS `question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `survey_id` int(11) NOT NULL,
  `input_type` varchar(30) NOT NULL,
  `question_statement` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `survey_id`, `input_type`, `question_statement`) VALUES
(4, 1, 'text', 'What did you learn today?'),
(5, 1, 'radio', 'What did you eat today?'),
(6, 7, 'radio', 'example question');

-- --------------------------------------------------------

--
-- Table structure for table `question_answer`
--

CREATE TABLE IF NOT EXISTS `question_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `answer` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `optional_explanation` tinytext NOT NULL,
  `survey_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `question_answer`
--

INSERT INTO `question_answer` (`id`, `question_id`, `answer`, `user_id`, `optional_explanation`, `survey_id`) VALUES
(8, 4, 'test answer', 16, '', 1),
(9, 5, 'Inorganic Food', 16, '', 1),
(10, 6, 'Option1', 16, '', 7);

-- --------------------------------------------------------

--
-- Table structure for table `question_choices`
--

CREATE TABLE IF NOT EXISTS `question_choices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `choice_statement` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `question_choices`
--

INSERT INTO `question_choices` (`id`, `question_id`, `choice_statement`) VALUES
(7, 5, 'Organic Food'),
(8, 5, 'Inorganic Food'),
(9, 5, 'Junk Food'),
(10, 5, 'Nothing'),
(11, 6, 'Option1');

-- --------------------------------------------------------

--
-- Table structure for table `sub_question`
--

CREATE TABLE IF NOT EXISTS `sub_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_question_id` int(11) NOT NULL,
  `sub_question_statement` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sub_question_answer`
--

CREATE TABLE IF NOT EXISTS `sub_question_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_question_id` int(11) NOT NULL,
  `answer` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `survey`
--

CREATE TABLE IF NOT EXISTS `survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(350) NOT NULL,
  `instructions` text NOT NULL,
  `status` varchar(30) NOT NULL,
  `entry_date` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `survey`
--

INSERT INTO `survey` (`id`, `title`, `instructions`, `status`, `entry_date`) VALUES
(1, 'Example Survey updated', 'test instructions updated', 'active', '21-03-2016'),
(7, 'Example Survey 1', 'instruction 1', 'active', '21-03-2016'),
(8, 'Example Survey 2', 'instructions 2', 'active', '21-03-2016'),
(10, 'My first Survey updated', 'My first Survey Instructions updated', 'active', '21-03-2016');

-- --------------------------------------------------------

--
-- Table structure for table `taken_survey`
--

CREATE TABLE IF NOT EXISTS `taken_survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `volunteer_id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `survey_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `taken_survey`
--

INSERT INTO `taken_survey` (`id`, `volunteer_id`, `survey_id`, `survey_date`) VALUES
(2, 16, 1, '11-04-2016'),
(3, 16, 7, '11-04-2016');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_login` varchar(50) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `imageurl` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_login` (`user_login`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_login`, `user_password`, `firstname`, `surname`, `gender`, `dob`, `address`, `imageurl`) VALUES
(16, 'shahid', 'shahid', 'Shahid', 'Baig', 'Male', '3/2/2007', 'test address', 'images/users/123.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
